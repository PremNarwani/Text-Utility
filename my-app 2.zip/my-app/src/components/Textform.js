import React,{useState} from 'react'

export default function Textform(props) {
  
   const handleUpClick =()=>{
    //  console.log("Button clicked" + text);
     let newText = text.toUpperCase();
     setText(newText)
     props.showAlert("Text converted to Uppercase","success")
   }
   const handleLoClick =()=>{
     let newText = text.toLowerCase();
     setText(newText)
     props.showAlert("Text converted to Lowercase","success")
   }
   const handleClear =()=>{
     let newText = "";
     setText(newText)
     props.showAlert("Text cleared","success")
   }
   const handleOnChange = (event) =>{
    //  console.log("txtarea was changed")
     setText(event.target.value);
   }
    const [text, setText] = useState("");

  return (
    <>
    <div style={{color:props.mode==="light"?"black":"white" }}>
        <h1  >{props.heading}</h1>
  <div className="mb-3">
   
    <textarea className="form-control" id="myBox" value={text} onChange={handleOnChange} style={{backgroundColor:props.mode==="light"?"white":"#474e54", color:props.mode==="light"?"black":"white"}} rows="8"></textarea>
    
  </div>
  <button className="btn btn-dark mx-2 my-2" onClick={handleUpClick}>Convert to UpperCase</button>
  <button className="btn btn-dark mx-2 my-2" onClick={handleLoClick}>Convert to LowerCase</button>
  <button className="btn btn-dark mx-2 my-2" onClick={handleClear}>Clear Text</button>

  </div>
  <div className="container my-3" style={{color:props.mode==="light"?"black":"white" }}>
    <h3>Your Text Summary</h3>
    <p>{text.split(" ").length} words, {text.length} characters</p>
    <p>{0.08*text.split(" ").length} minutes is the estimated time required for reading</p>
    <h3 >Preview</h3>
    <p>{text.length>0?text:"Enter something to preview it here"}</p>
  </div>
  
  </>
  )
}
